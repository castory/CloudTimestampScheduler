import boto3
from datetime import datetime

s3 = boto3.client('s3')
kms = boto3.client('kms')

def lambda_handler(event, context):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    encrypted_timestamp = kms.encrypt(KeyId=var.kms_key_arn, Plaintext=timestamp)['CiphertextBlob']
    
    s3.put_object(
        Bucket='kaigos02-mg',
        Key=f'timestamp_{timestamp}.txt',
        Body=encrypted_timestamp
    )
    print(f'Timestamp {timestamp} uploaded successfully.') 